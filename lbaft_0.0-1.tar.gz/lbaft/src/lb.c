#include <R.h>
#include <Rmath.h>
#include <math.h>

double get_rikjl(double *X, double *sigma,
		 int *N, int *p, int i, int j) {
  double *xdif = Calloc(*p, double);
  double rikjl = 0.0;
  int m = 0, q = 0;
 for (m = 0; m < *p; m++) {
    xdif[m] = 0.0;
    xdif[m] = X[i + m * *N] - X[j + m * *N];
  }
  for (m = 0; m < *p; m++) {
    for (q = 0; q < *p; q++) {
      rikjl += xdif[m] * sigma[m * *p + q] * xdif[q];
    }
  }
  rikjl = sqrt(rikjl);
  Free(xdif);
  return(rikjl);
}

void logRk(double*beta, double *Y, double *X, double *delta, double *lbw,
	   int *n, int *p, 
	   //output 
	   double *out) {
  int i, j, r;
  double *e = Calloc(*n, double); 
  double *ei = Calloc(*n, double); 
  double *nu = Calloc(*p, double); 
  double de;
  for (i = 0; i < *n; i++) {
    e[i] = 0.0;
    for (j = 0; j < *p; j++) {
      e[i] += X[j * *n + i] * beta[j];
    }
    ei[i] = Y[i] - e[i];
  }
  for (i = 0; i < *n; i++) {
    if (delta[i] != 0) {
      for ( r = 0; r < *p; r++) {
	nu[r] = 0.0;
      }
      de = 0.0;
      for (j = 0; j < *n; j++) {
	if (ei[i] <= ei[j]) {
	  for (r = 0; r < *p; r++) {
	    nu[r] += lbw[j + i * *n] * X[j + r * *n];
	}
	  de += lbw[j + i * *n];
	}
      } // end j
      for (r = 0; r < *p; r++) {
	out[r] += X[i + r * *n] - (nu[r] / de);
      }
    } // end delta
  } // end i
  Free(e);
  Free(ei);
  Free(nu);
  out;
}

void NSmoothGE(double*beta, double *Y, double *X, double *delta, double *lbw, 
	    int *n, int *p,
	   //output 
	   double *out) {
  int i, j, r;
  double *e = Calloc(*n, double); 
  double *ei = Calloc(*n, double); 
  for (i = 0; i < *n; i++) {
    e[i] = 0.0;
    for (j = 0; j < *p; j++) {
      e[i] += X[j * *n + i] * beta[j];
    }
    ei[i] = Y[i] - e[i];
  }
  for (i = 0; i < *n; i++) {
    if (delta[i] != 0) {    
      for (j = 0; j < *n; j++) {
    	if (ei[i] <= ei[j]) {
	  for (r = 0; r < *p; r++) {
	    out[r] += (X[i + r * *n] - X[j + r * *n]) * lbw[j + i * *n];
	  }
	}
      }
    }
  }
  Free(e);
  Free(ei);
  out;
}

void SmoothGE(double*beta, double *Y, double *X, double *delta, double *lbw, double *sigma,
	  int *n, int *p,
	   //output 
	   double *out) {
  int i, j, r;
  double z, H, rikjl;
  double *e = Calloc(*n, double); 
  double *ei = Calloc(*n, double); 
  for (i = 0; i < *n; i++) {
    e[i] = 0.0;
    for (j = 0; j < *p; j++) {
      e[i] += X[j * *n + i] * beta[j];
    }
    ei[i] = Y[i] - e[i];
  }
  for (i = 0; i < *n; i++) {
    if (delta[i] != 0) {    
      for (j = 0; j < *n; j++) {
	rikjl = get_rikjl(X, sigma, n, p, i, j);
	if (rikjl != 0) {
	  z = sqrt(*n) * (ei[j] - ei[i]) / rikjl;
	  H = pnorm(z, 0.0, 1.0, 1, 0);
	  for (r = 0; r < *p; r++) {
	    out[r] += (X[i + r * *n] - X[j + r * *n]) * H * lbw[j + i * *n];
	  }
	}
      }
    }    
  }
  Free(e);
  Free(ei);
  out;
}
