## Ning's estimates

fit.Ning <- function(Y, X, A, delta) {
    beta <- rep(0, ncol(X))
    dfsane(beta, eqNing, Y = Y, X = X, delta = delta, A = A,
           control = list(NM = FALSE, M = 100, noimp = 500, trace = FALSE))$par
}

eqNing <- function(beta, Y, X, delta, A) {
    n <- NROW(X)
    p <- ncol(X)
    out <- double(p)
    en <- Y - X %*% beta
    wgt <- matrix(0, length(en), length(en))
    cr <- exp(Y) - exp(A)
    shat <- NULL
    ord <- order(cr)
    cri <- cr[ord]
    deltai <- (1 - delta)[ord]
    repeats <- table(cri)
    ## Shati <- survfit(Surv(cri, deltai) ~ 1)$surv
    Shati <- exp(-basehaz(coxph(Surv(cri, deltai) ~ 1))$hazard)
    Shati <- rep(Shati, repeats)
    xdif <- c(diff(cri), 0)
    s <- c(0, cumsum(Shati * xdif)) + cri[1]
    w2 <- sapply(exp(Y) * exp(-1 * X %*% beta), riemS, x = cri, y = Shati, s = s)
    for (i in 1:length(en)) {
        wgt[,i] <- delta / w2
    }
    .C("ulblk2", as.double(beta), as.double(Y), as.double(X), as.double(delta),
       as.double(wgt), as.integer(n), as.integer(p),
       out = as.double(out))$out
}

## Shen's estimates

fit.Shen <- function(Y, X, A, delta) {
    n <- NROW(X)
    p <- ncol(X)
    out <- double(p)
    cr <- exp(Y) - exp(A)
    shat <- NULL
    ord <- order(cr)
    cri <- cr[ord]
    deltai <- (1 - delta)[ord]
    repeats <- table(cri)
    ## Shati <- survfit(Surv(cri, deltai) ~ 1)$surv
    Shati <- exp(-basehaz(coxph(Surv(cri, deltai) ~ 1))$hazard)
    Shati <- rep(Shati, repeats)
    xdif <- c(diff(cri), 0)
    s <- c(0, cumsum(Shati * xdif)) + cri[1]
    w2 <- sapply(exp(Y), riemS, x = cri, y = Shati, s = s)
    geese.fit(X, Y, weights = delta / w2, corstr = "indep", id = 1:NROW(X))$beta
}

## M1, M2 and M3

## Iterative used for non-gehan weight (only works for logrank here)
fit.GP <- function(formula, smooth = TRUE, data, contrasts = NULL, 
                 rankWeights = "logrank", vMethod = "M3", seMethod = "ZL",
                 B = 0, eta = NULL, binit = NULL, q = 0.5) {
    scall <- match.call()
    mnames <- c("", "formula", "data")
    cnames <- names(scall)
    cnames <- cnames[match(mnames, cnames, 0)]
    mcall <- scall[cnames]
    mcall[[1]] <- as.name("model.frame")
    m <- eval(mcall, parent.frame())
    resp <- model.extract(m, "response")
    mterms <- attr(m, "terms")
    X <- model.matrix(mterms, m, contrasts)
    Y <- log(resp[,2])
    A <- log(resp[,1])
    delta <- resp[,3]
    if (is.null(eta))
        eta <- rep(1, NROW(X))
    ## Point estimates
    tpe <- system.time(temp <- getGPPE(Y = Y, A = A, X = X, delta = delta,
                                       smooth = smooth, rankWeights = rankWeights,
                                       eta = eta, binit = binit, vMethod = vMethod, q = q))
    beta <- temp$beta
    owgt <- temp$owgt
    se <- covmat <- NULL
    if (B > 1) {
        ## variance estimate
        covmat <- getVar(Y, X, delta, beta, B, A, smooth, rankWeights, 
                         vMethod = vMethod, seMethod = seMethod, q = q)$covmat
    }
    out <- list(beta = beta, covmat = covmat, se = sqrt(diag(covmat)), tpe = tpe)
    return(out)
}

## Iterative used for gehan weight
fit.GE <- function(formula, smooth = TRUE, vMethod = "M3", contrasts = NULL, 
                  data, eta = NULL, binit = NULL, B = 0, seMethod = "ZL", q = 0.5) {
    scall <- match.call()
    mnames <- c("", "formula", "data")
    cnames <- names(scall)
    cnames <- cnames[match(mnames, cnames, 0)]
    mcall <- scall[cnames]
    mcall[[1]] <- as.name("model.frame")
    m <- eval(mcall, parent.frame())
    resp <- model.extract(m, "response")
    mterms <- attr(m, "terms")
    X <- model.matrix(mterms, m, contrasts)
    Y <- log(resp[,2])
    A <- log(resp[,1])
    delta <- resp[,3]
    if(is.null(eta))
        eta <- rep(1, NROW(X))
    ## Point estimates
    tpe <- system.time(temp <- getGEPE(Y = Y, A = A, X = X, delta = delta, smooth = smooth,
                                       binit = binit, eta = eta, vMethod = vMethod, q = q))
    beta <- temp$beta
    owgt <- temp$owgt
    se <- covmat <- NULL
    if (B > 1) {
        ## variance estimate
        covmat <- getVar(Y, X, delta, beta, B, A, smooth, rankWeights = "GE", 
                         vMethod = vMethod, seMethod = seMethod, q = q)$covmat
    }
    out <- list(beta = beta, covmat = covmat, se = sqrt(diag(covmat)), tpe = tpe)
    return(out)
}


## required background functions
getGEPE <- function(Y, A, X, delta, smooth = TRUE, eta = rep(1, NROW(X)),
                    binit = NULL, vMethod = "M3", q = 0.5) {
    p <- ncol(X)
    sigma <- diag(p)
    if (is.null(binit))
        b2 <- initial(Surv(exp(A), exp(Y), delta) ~ X - 1)
    else
        b2 <- binit
    for (i in 1:50) {
        b1 <- b2
        owgt <- getWgt(Y, X, delta, A, b1, "GE", eta, vMethod, q = q)
        wgt <- owgt$wgt
        beta <- rep(0,p)
        if (smooth == TRUE) {
            b2 <- dfsane(beta, sGE, Y = Y, X = X, delta = delta, wgt = t(eta * t(eta * wgt)),
                         sigma = diag(p),
                         control = list(NM = FALSE, M = 100, noimp = 50, trace = FALSE))$par
        }
        else{
            b2 <-  dfsane(beta, nsGE, Y = Y, X = X, delta = delta, wgt = t(eta * t(eta * wgt)),
                          control = list(NM = FALSE, M = 100, noimp = 50, trace = FALSE))$par
        }
        e <- as.numeric((b2 - b1) %*% (b2 - b1)) / as.numeric(b1 %*% b1)
        if (e < 0.001) {
            b1 <- b2
            break
        }
    }
    list(beta = b1, owgt = owgt)
}

getGPPE <- function(Y, A, X, delta, smooth = TRUE, rankWeights = "PW",
                    eta = rep(1, NROW(X)), binit = NULL, vMethod = "M3", q = 0.5) {
    p <- ncol(X)
    sigma <- diag(p)
    if (is.null(binit)) {
        b2 <- initial(Surv(exp(A), exp(Y), delta) ~ X - 1)
    }
    if (!is.null(binit)) 
        b2 <- binit
    for (i in 1:50) {
        b1 <- b2
        owgt <- getWgt(Y, X, delta, A, b1, rankWeights, rep(1, nrow(X)), vMethod, q = q)
        wgt <- owgt$wgt
        beta <- rep(0,p)
        if (smooth == TRUE) {
            b2 <- dfsane(beta, sGE, Y = Y, X = X, delta = delta,
                         wgt = t(eta * t(eta * wgt)), sigma = diag(p),
                         control = list(NM = FALSE, M = 100, noimp = 50, trace = FALSE))$par
        }
        else{
            b2 <-  dfsane(beta, nsGE, Y = Y, X = X, delta = delta, wgt = t(eta * t(eta * wgt)),
                         control = list(NM = FALSE, M = 100, noimp = 50, trace = FALSE))$par
        }
        e <- as.numeric((b2 - b1) %*% (b2 - b1)) / as.numeric(b1 %*% b1)
        if (e < 0.001) {
            b1 <- b2
            break
        }
    }
    list(beta = b1, owgt = owgt)
}

getVar <- function(Y, X, delta, beta, B, A, smooth, rankWeights,
                   owgt, vMethod = "M3", seMethod = "ZL", data = NULL, q = 0.5) {
    p <- length(beta)
    n <- NROW(X)
    UnV <- AnV <- zmat  <- matrix(0, ncol = B, nrow = p)
    An <- Vn <- NULL
    An <- matrix(0, ncol = p, nrow = p)
    owgt <- getWgt(Y, X, delta, A, beta, rankWeights, rep(1, n), vMethod, q = q)
    for (i in 1:B) {
        eta <- rexp(NROW(X))
        zmat[,i] <- rnorm(p)
        if (rankWeights == "GE") 
            wgti <- owgt$wgt
        else {
            wgti <- t(t(owgt$wgt) * colSums(owgt$vjde) / colSums(eta * owgt$vjde))
            wgti <- ifelse(wgti == Inf, 0, wgti)
            wgti <- ifelse(is.na(wgti), 0, wgti)
        }
        wgt <- getWgt(Y, X, delta, A, beta + n^(-0.5) * zmat[,i],
                      rankWeights, rep(1, n), vMethod, q)$wgt
        if (smooth == TRUE) {
            UnV[,i] <- sGE(beta, Y, X, delta, t(eta * t(eta * wgti)), diag(p)) * n ^ 0.5
            AnV[,i] <- sGE(beta + n^(-0.5) * zmat[,i], Y, X, delta, wgt, diag(p)) * n 
        }
        if (smooth == FALSE) {
            UnV[,i] <- nsGE(beta, Y, X, delta, t(eta * t(eta * wgti))) * n ^ 0.5
            AnV[,i] <- nsGE(beta + n^(-0.5) * zmat[,i], Y, X, delta, wgt) * n
        }
    }
    for (i in 1:p) {
        An[i,] <- lm(AnV[i,] ~ matrix(t(zmat), ncol = p) - 1)$coef
    }
    Vn <- var(t(UnV))
    covmat <- solve(An) %*% Vn %*% t(solve(An))
    list(covmat = covmat, An = An, Vn = Vn, UnV = UnV)
}

sGE <-  function(beta, Y, X, delta, wgt = matrix(1, NROW(X), NROW(X)),
                  sigma = diag(NROW(X))) {
    n <- NROW(X)
    p <- ncol(X)
    out <- double(p)
    .C("SmoothGE", as.double(beta), as.double(Y), as.double(X), as.double(delta), as.double(wgt),
       as.double(sigma), as.integer(n), as.integer(p), out = as.double(out),
       PACKAGE = "lbaft")$out / n
}

nsGE <-  function(beta, Y, X, delta, wgt = matrix(1, NROW(X), NROW(X))) {
    n <- NROW(X)
    p <- ncol(X)
    out <- double(p)
    .C("NSmoothGE", as.double(beta), as.double(Y), as.double(X), as.double(delta), as.double(wgt),
       as.integer(n), as.integer(p), out = as.double(out),
       PACKAGE = "lbaft")$out / n
}


getSuv <- function (Y, X, beta, N, delta, weights) {
  en <- Y - X %*% beta
  Shat <- fhat <- NULL
  dummy <- 1:N
  ord <- order(en)
  ei <- en[ord]
  weightsi <- weights[ord]
  deltai <- delta[ord]
  repeats <- table(ei)
  Shati <- exp(-1 * basehaz(coxph(Surv(ei, deltai) ~ 1, weights = weightsi))$hazard)
  Shati <- rep(Shati, repeats)
  Shatlast <- rev(Shati)[1]
  Shat[dummy[ord]] <- Shati
  list(Shat = Shat, Shatlast = Shatlast)
}

getWgt <- function(Y, X, delta, A, b, rankWeights = "GE", eta = rep(1, NROW(X)),
                   vMethod = "M3", q = 0.5) {
    n <- NROW(X)
    wgt <- vj <- matrix(0, n, n)
    shat <- vjde <- NULL
    ea <- A - X %*% b 
    en <- Y - X %*% b
    ev <- log(exp(Y) - exp(A)) - X %*% b
    if (vMethod != "M1") {
        cr <- exp(Y) - exp(A)
        dummy <- 1:n
        ord <- order(cr)
        cri <- cr[ord]
        deltai <- (1 - delta)[ord]
        repeats <- table(cri)
        Shati <- exp(-basehaz(coxph(Surv(cri, deltai) ~ 1))$hazard)
        ## Shati <- survfit(Surv(cri, deltai) ~ 1)$surv
        Shati <- rep(Shati, repeats)
        xdif <- c(diff(cri), 0)
        s <- c(0, cumsum(Shati * xdif)) + cri[1]
        w2 <- sapply(exp(Y), riemS, x = cri, y = Shati, s = s)
        if (vMethod == "M2")
            s2 <- sapply(exp(Y), findS, x = cri, y = Shati)
    }
    gp <- 1
    if (rankWeights == "PW")
        gp <- getSuv(Y, X, b, n, delta, rep(1, n))$Shat
    if (rankWeights == "GP")
        gp <- getSuv(Y, X, b, n, delta, rep(1, n))$Shat ^ (1 / ncol(X))
    for (j in 1:length(en)) {
        if (vMethod == "M1") {
            vj[j,] <- ifelse(en - ea[j] > 0, 1, 0)
        }
        if (vMethod == "M1new") {
            vj[j,] <- q * ifelse(en - ea[j] > 0, 1, 0) + (1 - q) * delta[j] * ifelse(en - ev[j] > 0, 1, 0) 
        }
        if (vMethod == "M2") {
            s1 <- sapply(exp(Y) - exp(en[j] + X %*% b), findS, x = cri, y = Shati)
            w1 <- sapply(exp(Y) - exp(en[j] + X %*% b), riemS, x = cri, y = Shati, s = s)
            vj[,j] <- delta * (w2 - w1) / w2 + (1 - delta) * (s1 - s2) / (1 - s2)
        }
        if (vMethod == "M3") {
            w1 <- sapply(exp(en[j] + X %*% b), riemS, x = cri, y = Shati, s = s)
                vj[,j] <- delta * w1 / w2
        }
    }
    vj <- ifelse(vj == Inf, 0, vj)
    vj <- ifelse(is.na(vj), 0, vj)
    if (rankWeights == "GE")
        wgt <- vj
    else{
        de <- ifelse(matrix(rep(en, n) - rep(en, each = n), n) >= 0, 1, 0)
        wgt <- t(t(c(gp) * vj) / colSums(t(eta * t(vj * de))))
        vjde <- vj * de
    }
    wgt <- ifelse(wgt == Inf, 0, wgt)
    wgt <- ifelse(is.na(wgt), 0, wgt)
    list(wgt = wgt, vjde = vjde)
}


initial <- function(formula, data, contrasts = NULL, smooth = TRUE) {
    scall <- match.call()
    mnames <- c("", "formula", "data")
    cnames <- names(scall)
    cnames <- cnames[match(mnames, cnames, 0)]
    mcall <- scall[cnames]
    mcall[[1]] <- as.name("model.frame")
    m <- eval(mcall, parent.frame())
    resp <- model.extract(m, "response")
    mterms <- attr(m, "terms")
    X <- model.matrix(mterms, m, contrasts)
    Y <- log(resp[,2])
    A <- log(resp[,1])
    delta <- resp[,3]
    n <- nrow(X)
    p <- ncol(X)
    sigma <- diag(p)
    b2 <- dfsane(rep(0, p), sGE, Y = Y, X = X, delta = delta, wgt = matrix(1, n, n), sigma = diag(p),
                 control = list(NM = FALSE, M = 100, noimp = 50, trace = FALSE))$par
    for (i in 1:50) {
        b1 <- b2
        ea <- A - X %*% b1
        ei <- Y - X %*% b1
        wgt <- matrix(0, n, n)
        for (j in 1:n) {
            wgt[j,] <- ei - ea[j]
        }
        wgt <- ifelse(wgt > 0, 1, 0)
        if (smooth == TRUE) {
            b2 <- dfsane(b1, sGE, Y = Y, X = X, delta = delta, wgt = wgt, sigma = diag(p),
                         control = list(NM = FALSE, M = 100, noimp = 50, trace = FALSE))$par
        }
        else {
            b2 <- dfsane(b1, nsGE, Y = Y, X = X, delta = delta, wgt = wgt, sigma = diag(p),
                         control = list(NM = FALSE, M = 100, noimp = 50, trace = FALSE))$par
        }
        e <- as.numeric((b2 - b1) %*% (b2 - b1)) / as.numeric(b1 %*% b1)
        if (e < 0.0001) {
            b1 <- b2
            break
        }
    }
    ## list(beta = b1, step = i)
    b1
}

riemS <- function(x, y, upper, s) {
    idx <- which.min(abs(upper - x))
    if (upper > min(x)) {
        out <- ifelse(upper >= x[idx],
                      s[idx] + (upper - x[idx]) * y[idx],
                      s[idx] - (x[idx] - upper) * y[idx - 1])
    }
    else { out <- upper * y[1] }
    out
}

findS <- function(x, y, upper) {
    ord <- order(x)
    xi <- x[ord]
    yi <- y[ord]
    idx <- which.min(abs(upper - xi))
    if (upper > min(xi)) {
        out <- ifelse(upper >= xi[idx], yi[idx], yi[idx - 1])
    }
    else{ out <- yi[1] }
    out
}

## M1 find Q

M1Q <- function(formula, data, contrasts = NULL, smooth = TRUE, rankWeights = "GE", B = 500) {
    scall <- match.call()
    mnames <- c("", "formula", "data")
    cnames <- names(scall)
    cnames <- cnames[match(mnames, cnames, 0)]
    mcall <- scall[cnames]
    mcall[[1]] <- as.name("model.frame")
    m <- eval(mcall, parent.frame())
    resp <- model.extract(m, "response")
    mterms <- attr(m, "terms")
    X <- model.matrix(mterms, m, contrasts)
    Y <- log(resp[,2])
    A <- log(resp[,1])
    delta <- resp[,3]
    n <- nrow(X)
    clsize <- Z <- gw <- weights <- rep(1, n)
    p <- ncol(X)
    sigma <- diag(p)
    eta <- rep(1, NROW(X))
    if (rankWeights == "GE") {
        b1 <- getGEPE(Y = Y, A = A, X = X, delta = delta, smooth = smooth,
                      binit = NULL, vMethod = "M1new", eta = eta, q = 0)$beta
        b2 <- getGEPE(Y = Y, A = A, X = X, delta = delta, smooth = smooth,
                      binit = NULL, vMethod = "M1new", eta = eta, q = 1)$beta
    }
   if (rankWeights != "GE") {
        b1 <- getGPPE(Y = Y, A = A, X = X, delta = delta, smooth = smooth,
                      rankWeights = rankWeights, binit = NULL, vMethod = "M1new", eta = eta, q = 0)$beta
        b2 <- getGPPE(Y = Y, A = A, X = X, delta = delta, smooth = smooth,
                      rankWeights = rankWeights, binit = NULL, vMethod = "M1new", eta = eta, q = 1)$beta
    }
    tmp1 <- getVar(Y, X, delta, b1, B, A, smooth, rankWeights = rankWeights,
                  vMethod = "M1new", seMethod = "ZL", q = 0)
    tmp2 <- getVar(Y, X, delta, b2, B, A, smooth, rankWeights = rankWeights,
                   vMethod = "M1new", seMethod = "ZL", q = 1)
    A1 <- tmp1$An
    A2 <- tmp2$An
    tr <- NULL
    for (i in seq(0, 1, 0.01)) {
        Vq <- var(t((1 - i) * tmp1$UnV + i * tmp2$UnV))
        Aq <- (1 - i) * A1 + i * A2
        covmatq <- solve(Aq) %*% Vq %*% t(solve(Aq))
        tr <- c(tr, sum(covmatq * diag(1, p)))
    }
    tr
}

